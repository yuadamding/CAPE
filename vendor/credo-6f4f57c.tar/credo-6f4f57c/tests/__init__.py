"""CREDO test package."""
