from __future__ import annotations

import json
import pkgutil
import shutil
from dataclasses import replace

import anndata as ad
import numpy as np
import pandas as pd
import pytest
import torch
import yaml
from pydantic import ValidationError

import credo
from credo.cli import main
from credo.contracts import SplitSpec
from credo.counterfactual import counterfactual
from credo.evaluation import (
    COMMON_DIAGNOSTIC_COLUMNS,
    COMMON_METRIC_COLUMNS,
    COMMON_PREDICTION_COLUMNS,
)
from credo.io import RunConfig, load_config, load_data, write_canonical_dataset
from credo.model import CREDOModel
from credo.registry import get_recipe
from credo.runtime import TrainingEngine
from credo.training import Trainer


def _fit(config, data):
    return TrainingEngine().fit(get_recipe(config.recipe), data, config, device="cpu")


def test_tiny_run_writes_generic_bundle_artifacts(trained_run) -> None:
    output = trained_run.config.output
    assert sorted(
        str(path.relative_to(output)) for path in output.rglob("*") if path.is_file()
    ) == sorted(
        [
            "run.json",
            "state/checkpoint.pt",
            "tables/history.parquet",
            "tables/predictions.parquet",
            "tables/metrics.parquet",
            "tables/diagnostics.parquet",
            "tables/counterfactuals.parquet",
        ]
    )
    history = pd.read_parquet(output / "tables/history.parquet")
    assert history["phase"].tolist() == ["state", "mass", "context"]
    assert history.loc[history["phase"].eq("state"), "bank_seen_fraction"].eq(0.0).all()
    assert (
        history.loc[history["phase"].isin({"mass", "context"}), "bank_seen_fraction"].eq(1.0).all()
    )
    assert history.loc[history["phase"].eq("state"), "validation_count_blocks"].eq(0).all()
    assert (
        history.loc[history["phase"].isin({"mass", "context"}), "validation_count_blocks"]
        .eq(2)
        .all()
    )
    assert history["validation_count_loss"].map(pd.notna).all()
    predictions = pd.read_parquet(output / "tables/predictions.parquet")
    metrics = pd.read_parquet(output / "tables/metrics.parquet")
    diagnostics = pd.read_parquet(output / "tables/diagnostics.parquet")
    assert predictions.columns.tolist() == list(COMMON_PREDICTION_COLUMNS)
    assert metrics.columns.tolist() == list(COMMON_METRIC_COLUMNS)
    assert diagnostics.columns.tolist() == list(COMMON_DIAGNOSTIC_COLUMNS)
    assert set(metrics["metric_name"]) == {
        "sinkhorn_divergence",
        "unbalanced_sinkhorn_divergence",
        "latent_energy_distance",
        "latent_centroid_distance",
        "latent_covariance_distance",
        "nearest_observed_state_accuracy",
        "log_abundance_squared_error",
    }
    manifest = json.loads((output / "run.json").read_text(encoding="utf-8"))
    assert manifest["mass_semantics"] == "relative_within_group"
    assert manifest["mass_denominators"] == [
        "D1::Rest::eligible_guides",
        "D1::Stim48hr::eligible_guides",
        "D1::Stim8hr::eligible_guides",
        "D2::Rest::eligible_guides",
        "D2::Stim48hr::eligible_guides",
        "D2::Stim8hr::eligible_guides",
    ]
    assert manifest["claim_policy"]["absolute_growth"] is False
    assert manifest["claim_policy"]["abundance_claim"] == "relative_only"
    assert manifest["runtime"] == {
        "device": "cpu",
        "dtype": "float32",
        "accelerator": {"type": "cpu", "name": "CPU", "cuda_runtime": None},
    }
    assert manifest["bank_initialization"]["bank_seen_fraction"] == 1.0
    assert manifest["validation_split"]["strategy"] == "context_group_holdout"


def test_checkpoint_roundtrip_reproduces_predictions(trained_run, tiny_data, tmp_path) -> None:
    assert trained_run.settings.evaluation.steps_per_interval is None
    assert trained_run.evaluation_steps_per_interval == trained_run.training_plan.steps_per_interval
    assert torch.equal(trained_run.grid, trained_run.training_grid)

    loaded = Trainer.load(
        trained_run.config.output / "state/checkpoint.pt",
        tiny_data,
        trained_run.config,
        device="cpu",
    )
    before = trained_run.metrics.reset_index(drop=True)
    after = loaded.metrics.reset_index(drop=True)
    pd.testing.assert_frame_equal(before, after, check_exact=True)

    higher_resolution = Trainer.load(
        trained_run.config.output / "state/checkpoint.pt",
        tiny_data,
        trained_run.config,
        device="cpu",
        evaluation_overrides={
            "particles": 10,
            "measures_per_batch": 6,
            "steps_per_interval": 2,
        },
    )
    assert higher_resolution.settings.evaluation.particles == 10
    assert higher_resolution.settings.evaluation.measures_per_batch == 6
    assert higher_resolution.settings.evaluation.steps_per_interval == 2
    expected_training_steps = (
        len(tiny_data.axis.labels) - 1
    ) * trained_run.training_plan.steps_per_interval
    expected_evaluation_steps = (len(tiny_data.axis.labels) - 1) * 2
    assert len(higher_resolution.training_grid) - 1 == expected_training_steps
    assert len(higher_resolution.evaluation_grid) - 1 == expected_evaluation_steps
    assert len(higher_resolution.grid) - 1 == expected_evaluation_steps
    assert (
        higher_resolution.validation_bank.tensors["context_log_mass"].shape[0]
        == expected_evaluation_steps
    )
    runtime_metrics = higher_resolution.evaluate_runtime(particles=4, seed=29)
    assert runtime_metrics["integration_steps"].eq(expected_evaluation_steps).all()

    settings = trained_run.settings
    wrong_model = settings.model.model_copy(update={"hidden_dim": settings.model.hidden_dim + 8})
    wrong_settings = settings.model_copy(update={"model": wrong_model})
    wrong_config = trained_run.config.model_copy(update={"recipe_config": wrong_settings})
    with pytest.raises(ValueError, match="architecture disagrees"):
        Trainer.load(
            trained_run.config.output / "state/checkpoint.pt",
            tiny_data,
            wrong_config,
            device="cpu",
        )

    wrong_training = settings.training.model_copy(
        update={"steps_per_interval": settings.training.steps_per_interval + 1}
    )
    wrong_settings = settings.model_copy(update={"training": wrong_training})
    wrong_config = trained_run.config.model_copy(update={"recipe_config": wrong_settings})
    with pytest.raises(ValueError, match="run contract disagrees"):
        Trainer.load(
            trained_run.config.output / "state/checkpoint.pt",
            tiny_data,
            wrong_config,
            device="cpu",
        )

    changed_meta = tiny_data.measure_meta.copy()
    changed_meta.loc[0, "sample_id"] = "changed-sample"
    changed_data = replace(tiny_data, measure_meta=changed_meta)
    with pytest.raises(ValueError, match="run contract disagrees"):
        Trainer.load(
            trained_run.config.output / "state/checkpoint.pt",
            changed_data,
            trained_run.config,
            device="cpu",
        )

    payload = torch.load(
        trained_run.config.output / "state/checkpoint.pt",
        map_location="cpu",
        weights_only=True,
    )
    payload.pop("envelope")
    missing_envelope = tmp_path / "missing-envelope.pt"
    torch.save(payload, missing_envelope)
    with pytest.raises(ValueError, match="missing its envelope"):
        Trainer.load(missing_envelope, tiny_data, trained_run.config, device="cpu")

    corrupted = torch.load(
        trained_run.config.output / "state/checkpoint.pt",
        map_location="cpu",
        weights_only=True,
    )
    state_name = next(iter(corrupted["model_state"]))
    corrupted["model_state"][state_name] = corrupted["model_state"][state_name].clone()
    corrupted["model_state"][state_name].reshape(-1)[0] += 1
    corrupted_checkpoint = tmp_path / "corrupted-model.pt"
    torch.save(corrupted, corrupted_checkpoint)
    with pytest.raises(ValueError, match="semantic hash"):
        Trainer.load(corrupted_checkpoint, tiny_data, trained_run.config, device="cpu")


def test_generic_run_loader_reconstructs_compact_predictions(trained_run) -> None:
    loaded = credo.open_run(trained_run.config.output / "run.json", device="cpu")
    try:
        pd.testing.assert_frame_equal(
            trained_run.metrics.reset_index(drop=True),
            loaded.metrics.reset_index(drop=True),
            check_exact=True,
        )
        declared = json.loads((trained_run.config.output / "run.json").read_text(encoding="utf-8"))[
            "split_plan"
        ]
        assert loaded.data.metadata["split_plan"] == declared
    finally:
        loaded.close()


def test_generic_run_manifest_rejects_corrupt_and_external_artifacts(
    trained_run,
    tmp_path,
) -> None:
    copied = tmp_path / "copied-run"
    shutil.copytree(trained_run.config.output, copied)
    checkpoint = copied / "state/checkpoint.pt"
    checkpoint.write_bytes(checkpoint.read_bytes() + b"corrupt")
    with pytest.raises(ValueError, match="Run artifact size mismatch"):
        credo.open_run(copied / "run.json")

    from credo.artifacts import write_run_json

    outside = tmp_path / "outside.bin"
    outside.write_bytes(b"state")
    with pytest.raises(ValueError, match="escapes its root"):
        write_run_json(
            tmp_path / "new-run",
            {"recipe": {"id": "fixture", "version": "1"}},
            artifacts={"../outside.bin": outside},
        )


def test_generic_run_loader_uses_the_saved_explicit_split(tiny_config, tmp_path) -> None:
    config = tiny_config.model_copy(update={"output": tmp_path / "explicit-split-run"})
    study = credo.open_study(config)
    try:
        requested = SplitSpec(
            strategy="measure",
            validation_values=("D1::GENE1-1",),
            representation_scope="shared",
        )
        trained = TrainingEngine().fit(
            get_recipe(config.recipe),
            config.view(study),
            config,
            split=requested,
            device="cpu",
        )
        trained.save()
    finally:
        study.close()
    loaded = credo.open_run(config.output / "run.json", device="cpu")
    try:
        assert loaded.validation_measure_ids == ("D1::GENE1-1",)
        assert loaded.validation_strategy == "within_embedding_holdout"
        pd.testing.assert_frame_equal(
            trained.metrics.reset_index(drop=True),
            loaded.metrics.reset_index(drop=True),
            check_exact=True,
        )
    finally:
        loaded.close()


def test_trainer_rejects_noncanonical_model_architecture(tiny_config, tiny_data) -> None:
    settings = tiny_config.recipe_config
    model = CREDOModel(
        embedding_ids=tiny_data.embedding_ids,
        control_embedding_ids=tiny_data.control_embedding_ids,
        latent_dim=tiny_data.latent_dim,
        embedding_dim=settings.model.embedding_dim,
        n_programs=settings.model.n_programs,
        hidden_dim=settings.model.hidden_dim,
        context_mode=settings.model.context,
        growth_max=2.0,
    )
    recipe = get_recipe(tiny_config.recipe)
    with pytest.raises(ValueError, match="architecture disagrees"):
        Trainer.from_plan(
            tiny_data,
            model,
            tiny_config,
            recipe.training_plan(tiny_data, settings),
            recipe.build_objectives(tiny_data, settings),
            device="cpu",
        )


def test_growth_bound_is_configured_in_the_model(tiny_config, tiny_data) -> None:
    settings = tiny_config.recipe_config
    model_config = settings.model.model_copy(update={"growth_max": 7.5})
    epochs = settings.training.epochs.model_copy(update={"state": 1, "mass": 0, "context": 0})
    training = settings.training.model_copy(update={"epochs": epochs})
    loss = settings.loss.model_copy(update={"mass": 0.0, "count": 0.0})
    settings = settings.model_copy(
        update={"model": model_config, "training": training, "loss": loss}
    )
    config = tiny_config.model_copy(update={"recipe_config": settings})
    trainer = _fit(config, tiny_data)
    assert trainer.model.growth_max == 7.5


def test_training_and_evaluation_use_separate_integration_grids(
    tiny_config,
    tiny_data,
    tmp_path,
    monkeypatch,
) -> None:
    settings = tiny_config.recipe_config
    epochs = settings.training.epochs.model_copy(update={"state": 1, "mass": 0, "context": 0})
    training = settings.training.model_copy(
        update={
            "epochs": epochs,
            "particles": 4,
            "steps_per_interval": 1,
            "measures_per_batch": 12,
            "checkpoint_selection": "last",
        }
    )
    evaluation = settings.evaluation.model_copy(
        update={
            "particles": 4,
            "measures_per_batch": 12,
            "steps_per_interval": 2,
        }
    )
    loss = settings.loss.model_copy(update={"mass": 0.0, "count": 0.0})
    settings = settings.model_copy(
        update={"training": training, "evaluation": evaluation, "loss": loss}
    )
    config = tiny_config.model_copy(
        update={"recipe_config": settings, "output": tmp_path / "separate-grids"}
    )

    rollout_steps: dict[str, list[int]] = {"training": [], "evaluation": []}
    original_rollout_ids = Trainer._rollout_ids

    def recording_rollout_ids(
        self,
        measure_ids,
        *,
        particles,
        seed,
        provider,
        data=None,
        grid=None,
    ):
        selected_grid = self.training_grid if grid is None else grid
        kind = "training" if data is None else "evaluation"
        rollout_steps[kind].append(len(selected_grid) - 1)
        return original_rollout_ids(
            self,
            measure_ids,
            particles=particles,
            seed=seed,
            provider=provider,
            data=data,
            grid=grid,
        )

    monkeypatch.setattr(Trainer, "_rollout_ids", recording_rollout_ids)
    trainer = _fit(config, tiny_data)

    interval_count = len(tiny_data.axis.labels) - 1
    assert set(rollout_steps["training"]) == {interval_count}
    assert set(rollout_steps["evaluation"]) == {2 * interval_count}
    assert len(trainer.training_grid) - 1 == interval_count
    assert len(trainer.evaluation_grid) - 1 == 2 * interval_count
    assert trainer.training_grid is trainer.training_grid
    assert trainer.evaluation_grid is trainer.evaluation_grid
    assert trainer.bank.tensors["context_log_mass"].shape[0] == interval_count
    assert trainer.validation_bank.tensors["context_log_mass"].shape[0] == 2 * interval_count
    with pytest.raises(ValueError, match="CatalogBank integration-step count"):
        trainer._refresh_bank_for(
            trainer.data,
            trainer.bank,
            epoch=trainer.completed_epochs,
            grid=trainer.evaluation_grid,
        )


def test_no_context_zero_count_skips_catalog_bank_without_changing_results(
    tiny_config,
    tiny_data,
    monkeypatch,
) -> None:
    from credo.recipes.compact_sde_v3 import training as training_runtime

    settings = tiny_config.recipe_config
    model = settings.model.model_copy(update={"context": "none"})
    epochs = settings.training.epochs.model_copy(update={"state": 1, "mass": 1, "context": 0})
    training = settings.training.model_copy(
        update={
            "epochs": epochs,
            "particles": 4,
            "steps_per_interval": 1,
            "measures_per_batch": 12,
            "checkpoint_selection": "last",
        }
    )
    evaluation = settings.evaluation.model_copy(update={"particles": 4, "measures_per_batch": 12})
    loss = settings.loss.model_copy(update={"count": 0.0})
    settings = settings.model_copy(
        update={
            "model": model,
            "training": training,
            "evaluation": evaluation,
            "loss": loss,
        }
    )
    config = tiny_config.model_copy(update={"recipe_config": settings})

    required = Trainer._catalog_bank_required
    monkeypatch.setattr(Trainer, "_catalog_bank_required", lambda self: True)
    legacy = _fit(config, tiny_data)
    monkeypatch.setattr(Trainer, "_catalog_bank_required", required)

    def unexpected_catalog_work(*args, **kwargs):
        raise AssertionError("inactive CatalogBank work was executed")

    monkeypatch.setattr(Trainer, "_refresh_bank", unexpected_catalog_work)
    monkeypatch.setattr(Trainer, "_refresh_bank_for", unexpected_catalog_work)
    monkeypatch.setattr(training_runtime.CatalogBank, "tick", unexpected_catalog_work)
    monkeypatch.setattr(
        training_runtime.CatalogBank,
        "update_from_rollout",
        unexpected_catalog_work,
    )
    optimized = _fit(config, tiny_data)

    assert optimized._catalog_bank_required() is False
    for name, parameter in legacy.model.state_dict().items():
        assert torch.equal(parameter, optimized.model.state_dict()[name])
    pd.testing.assert_frame_equal(
        legacy.metrics.reset_index(drop=True),
        optimized.metrics.reset_index(drop=True),
        check_exact=True,
    )


def test_training_progress_reports_throughput_without_changing_cpu_fit(
    tiny_config,
    tiny_data,
    capsys,
) -> None:
    settings = tiny_config.recipe_config
    epochs = settings.training.epochs.model_copy(update={"state": 2, "mass": 0, "context": 0})
    common_training = settings.training.model_copy(
        update={
            "epochs": epochs,
            "particles": 4,
            "steps_per_interval": 1,
            "checkpoint_selection": "last",
        }
    )
    evaluation = settings.evaluation.model_copy(update={"particles": 4})
    loss = settings.loss.model_copy(update={"mass": 0.0, "count": 0.0})
    baseline_settings = settings.model_copy(
        update={
            "training": common_training,
            "evaluation": evaluation,
            "loss": loss,
        }
    )
    baseline = _fit(
        tiny_config.model_copy(update={"recipe_config": baseline_settings}),
        tiny_data,
    )
    assert capsys.readouterr().out == ""

    reporting_training = common_training.model_copy(update={"progress_interval": 1})
    reporting_settings = baseline_settings.model_copy(update={"training": reporting_training})
    reporting = _fit(
        tiny_config.model_copy(update={"recipe_config": reporting_settings}),
        tiny_data,
    )
    records = [json.loads(line) for line in capsys.readouterr().out.splitlines() if line.strip()]

    assert [record["reason"] for record in records] == [
        "interval",
        "interval",
        "stage_end",
    ]
    assert [record["stage"] for record in records] == ["state", "state", "state"]
    assert [record["epoch"] for record in records] == [1, 2, 2]
    assert [record["stage_epoch"] for record in records] == [1, 2, 2]
    assert [record["window_epochs"] for record in records] == [1, 1, 2]
    assert all(record["event"] == "credo.training_progress" for record in records)
    assert all(record["window_seconds"] > 0 for record in records)
    assert all(record["epochs_per_second"] > 0 for record in records)
    assert all(record["particle_steps_per_second"] > 0 for record in records)
    assert all("cuda" not in record for record in records)
    for name, parameter in baseline.model.state_dict().items():
        assert torch.equal(parameter, reporting.model.state_dict()[name])
    pd.testing.assert_frame_equal(
        baseline.metrics.reset_index(drop=True),
        reporting.metrics.reset_index(drop=True),
        check_exact=True,
    )


def test_training_progress_reports_cuda_memory_without_requiring_cuda(
    monkeypatch,
    capsys,
) -> None:
    from credo.recipes.compact_sde_v3 import training as training_runtime

    trainer = object.__new__(Trainer)
    trainer.device = torch.device("cuda:0")
    trainer.completed_epochs = 7
    synchronized: list[torch.device] = []
    gib = 1024**3
    monkeypatch.setattr(
        torch.cuda,
        "synchronize",
        lambda device: synchronized.append(device),
    )
    monkeypatch.setattr(torch.cuda, "memory_allocated", lambda device: gib)
    monkeypatch.setattr(torch.cuda, "memory_reserved", lambda device: 2 * gib)
    monkeypatch.setattr(torch.cuda, "max_memory_allocated", lambda device: 3 * gib)
    monkeypatch.setattr(training_runtime.time, "perf_counter", lambda: 12.5)

    reported_at = trainer._emit_training_progress(
        stage="mass",
        stage_epoch=3,
        reason="interval",
        window_started=10.0,
        window_epochs=2,
        particle_steps=1_000,
    )
    record = json.loads(capsys.readouterr().out)

    assert reported_at == 12.5
    assert synchronized == [torch.device("cuda:0")]
    assert record["window_seconds"] == 2.5
    assert record["epochs_per_second"] == 0.8
    assert record["particle_steps_per_second"] == 400.0
    assert record["cuda"] == {
        "allocated_gib": 1.0,
        "reserved_gib": 2.0,
        "peak_allocated_gib": 3.0,
    }


def test_checkpoint_holdout_masks_training_and_evaluation_times(tiny_config, tiny_data) -> None:
    raw = tiny_config.model_dump()
    recipe_config = raw["recipe_config"]
    recipe_config["training"]["epochs"] = {"state": 1, "mass": 0, "context": 0}
    recipe_config["training"]["particles"] = 4
    recipe_config["evaluation"]["particles"] = 4
    recipe_config["validation"] = {
        "strategy": "checkpoint",
        "values": ["Stim8hr"],
        "fraction": 0,
        "representation_scope": "shared",
    }
    recipe_config["loss"] = {"mass": 0.0, "count": 0.0, "sinkhorn_epsilon": 0.1}
    config = RunConfig.model_validate(raw)
    trainer = _fit(config, tiny_data)
    assert trainer.train_time_labels == ("Stim48hr",)
    assert trainer.validation_time_labels == ("Stim8hr",)
    assert set(trainer.metrics["time_label"]) == {"Stim8hr"}
    expected_train_observations = len(tiny_data.measures["Stim48hr"])
    assert trainer.history_rows[0]["train_observations"] == expected_train_observations


def test_seed_reproduces_independent_fits(tiny_config, tiny_data, tmp_path) -> None:
    raw = tiny_config.model_dump()
    recipe_config = raw["recipe_config"]
    recipe_config["training"]["epochs"] = {"state": 1, "mass": 0, "context": 0}
    recipe_config["training"].update({"particles": 4})
    recipe_config["evaluation"].update({"particles": 4})
    recipe_config["loss"] = {"mass": 0.0, "count": 0.0}
    raw["output"] = tmp_path / "unused"
    config = RunConfig.model_validate(raw)
    first = _fit(config, tiny_data)
    second = _fit(config, tiny_data)
    for name, value in first.model.state_dict().items():
        assert value.equal(second.model.state_dict()[name])
    pd.testing.assert_frame_equal(first.metrics, second.metrics, check_exact=True)


def test_save_refuses_files_outside_the_artifact_contract(trained_run) -> None:
    extra = trained_run.config.output / "extra.csv"
    extra.write_text("stale\n", encoding="utf-8")
    try:
        with pytest.raises(FileExistsError, match="bundle contract"):
            trained_run.save()
    finally:
        extra.unlink()


def test_canonical_writer_persists_validated_counts_and_rejects_stale_files(
    tiny_config, tiny_data, tmp_path
) -> None:
    support = ad.read_h5ad(tiny_config.data.support)
    support.obs["atom_weight"] = support.obs["atom_weight"].astype(str)
    support.obsm["X_credo"] = support.obsm["X_credo"].astype("float64")
    measure_meta = pd.read_parquet(tiny_config.data.measure_meta)
    masses = pd.read_parquet(tiny_config.data.masses)
    counts = pd.read_parquet(tiny_config.data.counts)
    counts["exposure"] = counts["exposure"].astype(str)
    counts["count"] = counts["count"].astype(str)
    output = tmp_path / "canonical"
    write_canonical_dataset(
        output,
        support=support,
        measure_meta=measure_meta,
        masses=masses,
        axis=tiny_data.axis,
        mass_semantics=tiny_data.mass_semantics,
        counts=counts,
    )
    written = pd.read_parquet(output / "counts.parquet")
    assert pd.api.types.is_numeric_dtype(written["exposure"])
    assert pd.api.types.is_numeric_dtype(written["count"])
    written_support = ad.read_h5ad(output / "support.h5ad")
    assert pd.api.types.is_numeric_dtype(written_support.obs["atom_weight"])
    assert written_support.obsm["X_credo"].dtype.name == "float32"
    manifest = json.loads((output / "dataset.json").read_text(encoding="utf-8"))
    assert manifest["schema_version"] == 2
    assert manifest["representation"]["backend"] == "frozen_latent"
    assert manifest["representation"]["fit_scope"] == "external"
    assert manifest["representation"]["included_samples"] == []
    assert manifest["representation"]["included_time_labels"] == []
    data_config = tiny_config.data.model_copy(
        update={
            "support": output / "support.h5ad",
            "measure_meta": output / "measure_meta.parquet",
            "masses": output / "masses.parquet",
            "counts": output / "counts.parquet",
            "dataset": output / "dataset.json",
        }
    )
    loaded = load_data(tiny_config.model_copy(update={"data": data_config}))
    assert loaded.representation.to_dict() == manifest["representation"]

    with pytest.raises(FileExistsError, match="outside its contract"):
        write_canonical_dataset(
            output,
            support=support,
            measure_meta=measure_meta,
            masses=masses,
            axis=tiny_data.axis,
            mass_semantics=tiny_data.mass_semantics,
            counts=None,
        )


def test_lazy_support_matches_eager_loading_and_bounds_cache(tiny_config) -> None:
    lazy_data_config = tiny_config.data.model_copy(update={"support_cache_size": 2})
    lazy = load_data(tiny_config.model_copy(update={"data": lazy_data_config}))
    eager_data_config = tiny_config.data.model_copy(update={"lazy_support": False})
    eager = load_data(tiny_config.model_copy(update={"data": eager_data_config}))

    assert getattr(lazy.measures, "is_lazy", False) is True
    assert len(lazy.measures._cache) == 0
    support_view = lazy.support
    assert len(lazy.measures._cache) == 0
    source_id = next(iter(support_view[lazy.axis.source]))
    np.testing.assert_array_equal(
        support_view[lazy.axis.source][source_id],
        eager.measures[lazy.axis.source][source_id].support,
    )
    assert len(lazy.measures._cache) == 1
    for label in lazy.axis.labels:
        for measure_id in tuple(lazy.measures[label])[:3]:
            lazy_measure = lazy.measures[label][measure_id]
            eager_measure = eager.measures[label][measure_id]
            np.testing.assert_array_equal(lazy_measure.support, eager_measure.support)
            np.testing.assert_allclose(lazy_measure.weights, eager_measure.weights)
            assert lazy_measure.total_mass == eager_measure.total_mass
    assert len(lazy.measures._cache) <= 2
    lazy.measures.close()
    assert lazy.measures._handle is None


def test_lazy_support_validation_scans_for_nonfinite_values(tiny_config, tmp_path) -> None:
    support = ad.read_h5ad(tiny_config.data.support)
    latent = np.asarray(support.obsm[tiny_config.data.latent_key]).copy()
    latent[-1, -1] = np.nan
    support.obsm[tiny_config.data.latent_key] = latent
    corrupted_path = tmp_path / "nonfinite-support.h5ad"
    support.write_h5ad(corrupted_path)
    data_config = tiny_config.data.model_copy(update={"support": corrupted_path})

    with pytest.raises(ValueError, match="contains non-finite values"):
        load_data(tiny_config.model_copy(update={"data": data_config}))


def test_counterfactual_persistence_preserves_prior_rows(trained_run, tiny_data) -> None:
    path = trained_run.config.output / "tables/counterfactuals.parquet"
    manifest_path = trained_run.config.output / "run.json"
    original_artifact = path.read_bytes()
    original_manifest = manifest_path.read_bytes()
    noncontrols = tiny_data.measure_meta.loc[
        ~tiny_data.measure_meta["is_control"], "measure_id"
    ].tolist()
    columns = [
        "measure_id",
        "time_label",
        "context_policy",
        "delta_log_mass",
        "mean_shift_l2",
        "energy_distance",
        "context_dependence_shift",
        "factual_ess",
        "reference_ess",
    ]
    prior = {
        "measure_id": noncontrols[0],
        "time_label": tiny_data.axis.labels[1],
        "context_policy": "clamped",
        "delta_log_mass": 0.0,
        "mean_shift_l2": 0.0,
        "energy_distance": 0.0,
        "context_dependence_shift": 0.0,
        "factual_ess": 1.0,
        "reference_ess": 1.0,
    }
    try:
        pd.DataFrame([prior], columns=columns).to_parquet(path, index=False)
        loaded = Trainer.load(
            trained_run.config.output / "state/checkpoint.pt",
            tiny_data,
            trained_run.config,
            device="cpu",
        )
        counterfactual(loaded, noncontrols[1], context_policy="self_consistent")
        persisted = pd.read_parquet(path)
        keys = set(
            zip(
                persisted["measure_id"],
                persisted["time_label"],
                persisted["context_policy"],
                strict=False,
            )
        )
        assert (prior["measure_id"], prior["time_label"], prior["context_policy"]) in keys
        assert any(key[0] == noncontrols[1] for key in keys)
    finally:
        path.write_bytes(original_artifact)
        manifest_path.write_bytes(original_manifest)


def test_installed_surface_is_compact_and_recipe_runtime_is_explicit() -> None:
    modules = {module.name for module in pkgutil.iter_modules(credo.__path__)}
    assert modules == {
        "artifacts",
        "cli",
        "contracts",
        "counterfactual",
        "data",
        "evaluation",
        "io",
        "lps",
        "model",
        "objective",
        "particles",
        "problems",
        "recipes",
        "registry",
        "runtime",
        "training",
    }
    assert credo.__all__ == [
        "SelectionSpec",
        "SplitPlan",
        "Study",
        "StudyView",
        "PerturbSeqSelection",
        "PerturbSeqStudy",
        "PerturbSeqView",
        "PredictionQuery",
        "PredictionResult",
        "CounterfactualQuery",
        "CounterfactualResult",
        "bind_run_study",
        "counterfactual",
        "evaluate",
        "get_recipe",
        "load_config",
        "open_study",
        "open_run",
        "train",
        "write_study",
    ]


def test_cli_validate_and_summarize(tiny_config, trained_run, capsys, tmp_path) -> None:
    config_path = tmp_path / "config.yaml"
    config_path.write_text(yaml.safe_dump(tiny_config.model_dump(mode="json")), encoding="utf-8")
    assert main(["validate", str(config_path)]) == 0
    validation = json.loads(capsys.readouterr().out)
    assert validation["measure_count"] == 12
    assert main(["summarize", str(trained_run.config.output)]) == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["prediction_rows"] == len(trained_run.metrics)
    metrics_path = tmp_path / "cli_metrics.parquet"
    assert (
        main(
            [
                "evaluate",
                str(trained_run.config.output / "state/checkpoint.pt"),
                "--config",
                str(config_path),
                "--output",
                str(metrics_path),
                "--particles",
                "4",
                "--seed",
                "19",
            ]
        )
        == 0
    )
    evaluated = json.loads(capsys.readouterr().out)
    assert evaluated["status"] == "evaluated"
    assert len(pd.read_parquet(metrics_path)) == evaluated["rows"]
    with pytest.raises(ValidationError, match="greater than or equal to 0"):
        main(["run", str(config_path), "--seed", "-1"])


def test_config_rejects_duplicate_yaml_keys(tmp_path) -> None:
    config_path = tmp_path / "duplicate.yaml"
    config_path.write_text("output: first\noutput: second\n", encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate key 'output'"):
        load_config(config_path)
